var searchData=
[
  ['logica_2eh',['logica.h',['../logica_8h.html',1,'']]]
];

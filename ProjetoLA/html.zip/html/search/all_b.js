var searchData=
[
  ['possivel_5fjogar',['possivel_jogar',['../logica_8h.html#a5d6c3f49db97c5c6317fe53d0cb6af53',1,'logica.c']]]
];

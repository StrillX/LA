var searchData=
[
  ['jogada',['JOGADA',['../structJOGADA.html',1,'']]]
];

var searchData=
[
  ['casa_5ffinal',['casa_final',['../dados_8h.html#adc839b5b07de85fcd71f002d76ad378c',1,'dados.c']]],
  ['consulta_5fjogador',['consulta_jogador',['../dados_8h.html#a2c362b52acc2b5010a20a7aa36818dad',1,'dados.c']]],
  ['consulta_5fposicao',['consulta_posicao',['../dados_8h.html#a30ed3311c93662ed15ec88bdc86d9855',1,'dados.c']]],
  ['convertelinha',['convertelinha',['../interface_8h.html#a0096ae2fafe42cc41650df4856ba7fa1',1,'interface.c']]]
];

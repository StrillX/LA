var searchData=
[
  ['num_5fcomando',['num_comando',['../structESTADO.html#adf1064dfc09145b6995a7897249f1674',1,'ESTADO']]],
  ['num_5fjogadas',['num_jogadas',['../structESTADO.html#a261495728744647e618b4e623f5a4b7a',1,'ESTADO']]]
];

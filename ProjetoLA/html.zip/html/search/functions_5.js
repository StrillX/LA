var searchData=
[
  ['jogada_5fvalida',['jogada_valida',['../logica_8h.html#ab1160bacb55fe9977b2a60e615c2e627',1,'logica.c']]],
  ['jogar',['jogar',['../logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'logica.c']]]
];

var searchData=
[
  ['mostra_5fprompt',['mostra_prompt',['../interface_8h.html#a9eb2813a6ac1e79a76f920f9a4f32bb6',1,'interface.c']]],
  ['mostrar_5ftabuleiro',['mostrar_tabuleiro',['../interface_8h.html#a49c8e6516320a095ffd3cf91405cecee',1,'interface.c']]],
  ['muda_5fpos_5fultima',['muda_pos_ultima',['../dados_8h.html#a4bea65e08fbf43bd3797e37072e44bdb',1,'dados.c']]]
];

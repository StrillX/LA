var searchData=
[
  ['ler',['ler',['../interface_8h.html#a3c9d2903a3d77586bdfecd5c5a18d84d',1,'interface.c']]],
  ['logica_2eh',['logica.h',['../logica_8h.html',1,'']]]
];

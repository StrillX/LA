var searchData=
[
  ['atualiza_5festado_5fcasa',['atualiza_estado_casa',['../dados_8h.html#ae926426c10698aeb0cfab3ab6507313e',1,'dados.c']]],
  ['atualiza_5fjogador',['atualiza_jogador',['../dados_8h.html#a5145e20d5e4abdb6ca062e18cee9efab',1,'dados.c']]],
  ['atualiza_5fultima',['atualiza_ultima',['../dados_8h.html#a92a53c83eed376d935acbf128a409c11',1,'dados.c']]]
];

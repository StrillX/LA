var searchData=
[
  ['dados_2eh',['dados.h',['../dados_8h.html',1,'']]],
  ['distancia',['distancia',['../logica_8h.html#a9d81453517dfb252a97ca498601cdd16',1,'logica.c']]]
];

var searchData=
[
  ['pos',['pos',['../interface_8h.html#a5502a84da6d5bffda87a2ab6ee43c163',1,'interface.c']]],
  ['possivel_5fjogar',['possivel_jogar',['../logica_8h.html#a5d6c3f49db97c5c6317fe53d0cb6af53',1,'logica.c']]]
];

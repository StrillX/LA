var searchData=
[
  ['jog',['jog',['../interface_8h.html#a9dfbc982d23a619e36575d8e7ec8e41c',1,'interface.c']]],
  ['jog2',['jog2',['../interface_8h.html#a75a3c6feb2f2ec713f96559558b136d0',1,'interface.c']]],
  ['jogada',['JOGADA',['../structJOGADA.html',1,'']]],
  ['jogada_5fvalida',['jogada_valida',['../logica_8h.html#ab1160bacb55fe9977b2a60e615c2e627',1,'logica.c']]],
  ['jogadas',['jogadas',['../structESTADO.html#afae43b87a488fad0f2b56a18bad31d18',1,'ESTADO::jogadas()'],['../dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;dados.h']]],
  ['jogador_5fatual',['jogador_atual',['../structESTADO.html#a5dd28e2e68b7aef2b6b7ea88e02eff58',1,'ESTADO']]],
  ['jogar',['jogar',['../logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'logica.c']]]
];

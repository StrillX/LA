var searchData=
[
  ['jog',['jog',['../interface_8h.html#a9dfbc982d23a619e36575d8e7ec8e41c',1,'interface.c']]],
  ['jog2',['jog2',['../interface_8h.html#a75a3c6feb2f2ec713f96559558b136d0',1,'interface.c']]],
  ['jogada_5fvalida',['jogada_valida',['../logica_8h.html#ab1160bacb55fe9977b2a60e615c2e627',1,'logica.c']]],
  ['jogar',['jogar',['../logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'logica.c']]]
];

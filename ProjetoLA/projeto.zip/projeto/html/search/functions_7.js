var searchData=
[
  ['ler',['ler',['../interface_8h.html#a9666d1e07aff3ca224916eb121dc11e9',1,'interface.c']]],
  ['listagem_5fde_5fjogadas',['listagem_de_jogadas',['../logica_8h.html#a3fcfdc9778d725b67d8d6fc2fc5729c1',1,'logica.c']]]
];

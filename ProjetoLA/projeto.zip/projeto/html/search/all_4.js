var searchData=
[
  ['fim_5fjogo',['fim_jogo',['../logica_8h.html#ad3c7054170580d3d9c74e7d5cdd00395',1,'logica.c']]]
];

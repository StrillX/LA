var searchData=
[
  ['inicializar_5festado',['inicializar_estado',['../dados_8h.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'dados.c']]],
  ['inseremovs',['inseremovs',['../interface_8h.html#a7fb08231327a3410b30705f367e50c67',1,'interface.c']]],
  ['interface_2eh',['interface.h',['../interface_8h.html',1,'']]],
  ['interpretador',['interpretador',['../interface_8h.html#a24da95ebeede4a540e37790ce8be359b',1,'interface.c']]]
];

# LA
Projeto LA
Grupo 6,PL1,LCC;

A91699 Pedro Miguel Marques Fernandes;

A91643 Eduardo Nuno Teniz Freitas;

A91680 Bruno Filipe Jardim Machado;

